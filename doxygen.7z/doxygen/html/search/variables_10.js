var searchData=
[
  ['updatedate_0',['UpdateDate',['../d4/d86/my_footer_8cpp.html#ad589f11ca87a3a1c31852ea9284b6390',1,'myFooter.cpp']]],
  ['updatetime_1',['UpdateTime',['../d4/d86/my_footer_8cpp.html#adb0e6752114b53a88fa267e5a989595e',1,'myFooter.cpp']]]
];
