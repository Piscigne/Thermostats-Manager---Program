var searchData=
[
  ['ontimedate_0',['onTimeDate',['../d4/d86/my_footer_8cpp.html#a22ac60b1b7703100c77046ec3551ca79',1,'myFooter.cpp']]],
  ['ontimetime_1',['onTimeTime',['../d4/d86/my_footer_8cpp.html#a4d30af5d1e7f4532df0fb7a2c0d5d691',1,'myFooter.cpp']]]
];
